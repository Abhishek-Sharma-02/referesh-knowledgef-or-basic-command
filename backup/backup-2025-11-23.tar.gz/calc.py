num1 = int(input("Enter your first number"))
num2 = int(input("Enter your second number"))

add = num1 + num2
sub = num1-num2
division= num1/num2
multiple=num1*num2
percentage=num1%num2

print(type(add))
print(type(sub))

print("The add of the number :", add)
print("The sub of the number :", sub)
print("The division of the number :", division)
print("The multiple of the number :", multiple)
print("The percentage of the number :", percentage)